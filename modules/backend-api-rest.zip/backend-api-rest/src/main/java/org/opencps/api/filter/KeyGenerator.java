package org.opencps.api.filter;

import java.security.Key;

public interface KeyGenerator {

    Key generateKey();
}
