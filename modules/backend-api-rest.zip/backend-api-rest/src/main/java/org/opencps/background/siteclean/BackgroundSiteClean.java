package org.opencps.background.siteclean;

public class BackgroundSiteClean {
	private int percentage;
	private String executionLog;
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	public String getExecutionLog() {
		return executionLog;
	}
	public void setExecutionLog(String executionLog) {
		this.executionLog = executionLog;
	}
	
}
