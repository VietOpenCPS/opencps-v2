package org.opencps.api.controller.util;

import java.text.SimpleDateFormat;

public class OpenCPSUtils {
	public static SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
}
